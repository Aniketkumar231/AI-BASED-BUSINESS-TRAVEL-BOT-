import google.generativeai as genai
import os
import sys
from dotenv import load_dotenv

# --- 1. Configuration and API Key Loading ---
def configure_gemini():
    """Loads API key from .env file and configures the Gemini client."""
    load_dotenv()  # Load environment variables from .env file
    api_key = os.getenv("GOOGLE_API_KEY")

    if not api_key:
        print("ERROR: GOOGLE_API_KEY not found in environment variables.")
        print("Please create a '.env' file in the same directory as this script")
        print( GOOGLE_API_KEY=AIzaSyBkgPst0cxtS3g8_FJKBWP7QSFWbrrZAYQ
)
        sys.exit(1) # Exit if key is missing

    try:
        genai.configure(api_key=api_key)
        print("Gemini API configured successfully.")
    except Exception as e:
        print(f"Error configuring Gemini API: {e}")
        print("Please ensure your API key is valid.")
        sys.exit(1)

# --- 2. Model Initialization ---
def initialize_model():
    """Initializes the Gemini model with specific instructions and safety settings."""

    # --- Define the Bot's Role and Constraints ---
    system_instruction = """You are BizTravelBot, an AI assistant specializing exclusively in business travel.
Your ONLY function is to answer questions directly related to planning, managing, and undertaking travel for professional purposes.

Allowed topics include:
- Booking flights, hotels, and rental cars for business trips.
- Understanding and managing travel expenses and reporting.
- Packing tips specifically for business travelers (e.g., attire, gadgets).
- Information about visas and entry requirements for common business destinations (general info, not legal advice).
- Navigating corporate travel policies.
- Airline and hotel loyalty programs in a business context.
- Safety and security tips while traveling for work.
- Using airport lounges and amenities relevant to business travelers.
- Ground transportation options (taxis, ride-sharing, public transport) for business needs.
- Managing time zones and jet lag during business trips.
- Basic information about common business travel destinations (e.g., major airports, business districts - not tourist advice).
- Tips for staying productive while traveling for work.
- Understanding per diems and travel allowances.
- Currency exchange information relevant to business trips.

If the user asks a question that is NOT directly related to these business travel topics (e.g., questions about leisure travel, vacation planning, history, science, cooking, coding, politics, sports, medical advice unrelated to travel emergencies, financial investment advice, personal relationship advice, general knowledge), you MUST politely decline to answer.
State clearly that you can only discuss business travel topics. For example: "My apologies, I can only assist with questions related to business travel, such as booking, expenses, or packing for work trips." Do not attempt to answer the non-business-travel question in any way or engage in off-topic conversation.
Keep your answers professional, helpful, concise, and focused on providing practical information for business travelers. Avoid giving specific financial or legal advice that requires a qualified professional. You can suggest consulting company policy or official sources where appropriate."""

    # --- Model Configuration ---
    generation_config = {
      "temperature": 0.6,  # Slightly less creative, more focused on facts
      "top_p": 0.95,
      "top_k": 40,
      "max_output_tokens": 1024, # Limit response length
    }

    safety_settings = [
      {"category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_MEDIUM_AND_ABOVE"},
      {"category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_MEDIUM_AND_ABOVE"},
      {"category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_MEDIUM_AND_ABOVE"},
      {"category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_MEDIUM_AND_ABOVE"},
    ]

    try:
        # Using gemini-1.5-flash for speed, but gemini-pro is also suitable
        model = genai.GenerativeModel(
            model_name="gemini-1.5-flash",
            generation_config=generation_config,
            safety_settings=safety_settings,
            system_instruction=system_instruction # Apply the specific instructions
        )
        print("Gemini model initialized (gemini-1.5-flash) as BizTravelBot.")
        return model
    except Exception as e:
        print(f"Error initializing Gemini model: {e}")
        sys.exit(1)

# --- 3. Chat Loop ---
def run_chat_loop(model):
    """Starts and manages the interactive chat session."""
    try:
        chat = model.start_chat(history=[]) # Start a new chat session
        print("\n✈️ Welcome to BizTravelBot! ✈️")
        print("I can help with questions about business travel.")
        print("Ask about bookings, expenses, packing, policies, etc.")
        print("Type 'quit', 'exit', or 'bye' to end the chat.")
        print("-" * 50)

        while True:
            user_prompt = input("You: ").strip()

            if not user_prompt:
                continue # Ask for input again if empty

            user_prompt_lower = user_prompt.lower()
            if user_prompt_lower in ["quit", "exit", "bye"]:
                print("BizTravelBot: Safe travels! Goodbye.")
                break

            try:
                # Send only the user's message to the ongoing chat
                response = chat.send_message(user_prompt, stream=False)

                # --- Handle potential blocking or empty responses ---
                if response.prompt_feedback and response.prompt_feedback.block_reason:
                     print(f"BizTravelBot: I cannot process that request due to safety guidelines ({response.prompt_feedback.block_reason}).")
                # Check if response text is effectively empty AFTER stripping whitespace
                elif not response.parts or not response.text.strip():
                     # Try to get more specific block reason if available from candidates
                     block_reason_detail = "unknown reason (possibly filtered or off-topic)"
                     # Check if candidates list exists and is not empty
                     if response.candidates:
                         # Check finish_reason of the first candidate
                         if response.candidates[0].finish_reason != 'STOP':
                            block_reason_detail = f"finish reason: {response.candidates[0].finish_reason}"
                         # Additionally, check safety ratings if available
                         elif response.candidates[0].safety_ratings:
                             for rating in response.candidates[0].safety_ratings:
                                 if rating.blocked:
                                     block_reason_detail = f"safety block: {rating.category}"
                                     break # Found a safety block reason

                     print(f"BizTravelBot: My apologies, I couldn't generate a response ({block_reason_detail}). Remember, I can only assist with business travel topics.")
                else:
                     # Print the valid response text
                     print(f"BizTravelBot: {response.text}")

            except Exception as e:
                print(f"\nBizTravelBot: Sorry, an error occurred while getting the response: {e}")
                # Consider adding more robust error handling here if needed (e.g., retry logic)

    except Exception as e:
        print(f"Error starting or running chat session: {e}")
        sys.exit(1)


# --- 4. Main Execution ---
if __name__ == "__main__":
    configure_gemini()
    generative_model = initialize_model()
    run_chat_loop(generative_model)